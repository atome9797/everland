
const swapCam = () => {

    // faceTracking 일때만 카메라 전환 가능
    const direction = document.getElementById('cameraPosition').getAttribute('value') === 'front' ? 'back' : 'front'
    document.getElementById('cameraPosition').setAttribute('value', `${direction}`)

    //유니티에 보내주는 함수
    myInstance.SendMessage('GameManager', 'CameraSwap', direction);

    // 해당 카테고리 메뉴에 대한 클릭 이벤트 발동 시키기
    const selectCategory = document.getElementById('selectCategory').getAttribute('value')
    const chooseButton = document.querySelector(`.${selectCategory}`)
    chooseButton.click()
}

    // unity 에 넘겨주는 함수
    const camBtn2 = document.querySelector('.camera_chg_btn_type2')
    const camBtn = document.querySelector('.camera_chg_btn')


    camBtn2.addEventListener('click', swapCam)
    camBtn.addEventListener('click', swapCam)

    



